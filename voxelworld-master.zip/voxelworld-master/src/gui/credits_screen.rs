use super::{init_egui_input_state, menu_text, set_ui_gl_state, transparent_frame};
use crate::game::{EventHandler, Game};
use crate::gfx;
use egui_backend::egui::{self, vec2, Color32, Pos2};
use egui_gl_glfw as egui_backend;
use glfw::{Context, Glfw, PWindow};
use std::fs::File;
use std::io::Read;

//Read `assets/credits.txt` and return the contents as a vector of strings where
//each element of the vector is a line in the file
fn read_credits_text() -> Vec<String> {
    let path = "assets/credits.txt";
    match File::open(path) {
        Ok(mut file) => {
            let mut buf = String::new();
            let res = file.read_to_string(&mut buf);
            match res {
                Ok(sz) => eprintln!("read {sz} bytes from {path}"),
                Err(msg) => eprintln!("{msg}"),
            }
            buf.lines().map(|s| s.to_string()).collect()
        }
        Err(msg) => {
            eprintln!("Failed to open: {path}");
            eprintln!("{msg}");
            vec![]
        }
    }
}

//Display the credits, line by line
fn display_credits(ui: &mut egui::Ui, credits: &[String]) {
    for text in credits {
        ui.label(menu_text(text, 20.0, Color32::DARK_GRAY));
    }
}

//Display credits
pub fn run_credits_screen(
    gamestate: &mut Game,
    window: &mut PWindow,
    glfw: &mut Glfw,
    events: &EventHandler,
) -> bool {
    let mut painter = egui_backend::Painter::new(window);
    let ctx = egui::Context::default();
    let native_pixels_per_point = window.get_content_scale().0;
    let font = gamestate.get_font();
    ctx.set_fonts(font);
    ctx.set_pixels_per_point(native_pixels_per_point);

    //Initialize egui input state
    let mut input_state = init_egui_input_state(window);

    let credits_text = read_credits_text();
    set_ui_gl_state();
    window.set_cursor_mode(glfw::CursorMode::Normal);
    let start = std::time::Instant::now();
    let mut quit_to_menu = false;
    while !window.should_close() && !quit_to_menu {
        //Display
        gfx::clear();

        //Update input state
        input_state.input.time = Some(start.elapsed().as_secs_f64());
        input_state.pixels_per_point = native_pixels_per_point;
        let (w, h) = window.get_size();
        painter.set_size(w as u32, h as u32);

        ctx.begin_pass(input_state.input.take());

        //Display credits
        let (width, height) = window.get_size();
        let gui_width = 800.0f32.min(width as f32 - 32.0);
        egui::Window::new("window")
            .movable(false)
            .title_bar(false)
            .fixed_size(vec2(gui_width, height as f32))
            .fixed_pos(Pos2::new(width as f32 / 2.0 - gui_width / 2.0, 0.0))
            .frame(transparent_frame())
            .show(&ctx, |ui| {
                ui.vertical(|ui| {
                    ui.vertical_centered(|ui| {
                        ui.label(menu_text("Credits", 48.0, Color32::WHITE));

                        //Return to main menu
                        if ui
                            .button(menu_text("Main Menu", 24.0, Color32::WHITE))
                            .clicked()
                        {
                            quit_to_menu = true;
                        }
                    });

                    ui.add_space(24.0);

                    egui::ScrollArea::vertical()
                        .max_height(height as f32 - 160.0)
                        .show(ui, |ui| {
                            display_credits(ui, &credits_text);
                        });
                });
            });

        //End frame
        let egui::FullOutput {
            platform_output,
            textures_delta,
            shapes,
            pixels_per_point: _,
            viewport_output: _,
        } = ctx.end_pass();

        //Handle copy pasting
        for command in platform_output.commands {
            if let egui::OutputCommand::CopyText(copied_text) = command {
                egui_backend::copy_to_clipboard(&mut input_state, copied_text);
            }
        }

        //Display
        let clipped_shapes = ctx.tessellate(shapes, native_pixels_per_point);
        painter.paint_and_update_textures(
            native_pixels_per_point,
            &clipped_shapes,
            &textures_delta,
        );

        //Handle/update input states
        gamestate.update_input_states();
        gamestate.handle_events_egui(events, &mut input_state);
        gfx::output_errors();
        window.swap_buffers();
        glfw.poll_events();
    }

    quit_to_menu
}
