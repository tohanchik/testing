#ifndef AURORA_CAMERA_H
#define AURORA_CAMERA_H

#include <Source/Aurora/Math/Vector3.h>
#include <Source/Aurora/Math/Frustum.h>
#include <pspmath.h>

using namespace Aurora::Math;

namespace Aurora
{
	namespace Graphics
	{
		class Camera
		{
		public:
			Camera();
			virtual ~Camera();

			void PositionCamera(float positionX, float positionY, float positionZ,
				float viewX, float viewY, float viewZ,
				float upVectorX, float upVectorY, float upVectorZ);

			void Move(float speed);
			void MoveTo(Vector3 newPos);
			void MovePhysic(float speed);
			Vector3 MoveFoCollision(float speed);
			void MoveAfterCollision(Vector3 newPos);

			void Strafe(float speed);
			void StrafePhysic(float speed);

			void MovePhysicNoY(float speed);

			void RotateView(float angle, float x, float y, float z);
			void PitchView(float speed);

			float atan_(float y, float x);

			Frustum mFrustum;
			bool needUpdate;

			// The camera's position
			Vector3 m_vPosition;

			// The camera's offset
			Vector3 m_vOffset;

			// The camera's view
			Vector3 m_vView;

			// The camera's up vector
			Vector3 m_vUpVector;

			// The camera's strafe vector
			Vector3 m_vStrafe;

			Vector3 m_vVelocity;

			Vector3 vVector;

			float horAngle;

			float upDownAngle;
			float upDownAngle2;
		};
	}
}

#endif